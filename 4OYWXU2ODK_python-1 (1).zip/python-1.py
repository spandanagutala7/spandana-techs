print("hello world")
print("welcome to python")
print("daiva spandana gutala")
print("I am learning python")
print("python programming")
print("Good morning")
print("Welcome students")
a="python is easy"
print(a)
x="my first program"
print(x)
print("hello from python")